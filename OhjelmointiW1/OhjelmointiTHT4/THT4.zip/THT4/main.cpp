#include "Katutaso.h"
#include "Kerros.h"
#include "kerrostalo.h"
#include "asunto.h"

int main() {
   /* Asunto as1;
    Asunto as2;
    Asunto as3;
    Asunto as4;
*/
    Kerros kerros;
    Katutaso katutaso;
    Kerrostalo kerrostalo;
    Asunto asunto;

    kerros.maaritaAsunnot();
    katutaso.maaritaAsunnot();
    //asunto.maarita(2,100);

    double hinta = 1.0;
    double kulutus = kerros.laskeKulutus(hinta) + katutaso.laskeKulutus(hinta) + kerrostalo.laskeKulutus(hinta)-400;
    std::cout << "Kerros ja Katutaso yhteiskulutus + kerrostalo, kun hinta = " << hinta << " on " << kulutus << std::endl;


    return 0;
}
