#include "asunto.h"
#include <iostream>
using namespace std;



Asunto::Asunto(){
    cout<<"asunto luotu"<<endl;
}


void Asunto::maarita(int a, int n)
{
    asukasMaara = a;
    neliot = n;
    cout<<"Asunto maaritelty, asukkaita= "<<asukasMaara<<" nelioita= "<<neliot<<endl;
}



double Asunto::laskeKulutus(double h)
{
    double kulutus = h*asukasMaara*neliot;

  //  cout<<"asunnon kulutus, kun hinta="<<h<<" on "<<kulutus<<endl;

    return kulutus;
}

