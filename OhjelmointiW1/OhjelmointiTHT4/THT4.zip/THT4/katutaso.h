#ifndef KATUTASO_H
#define KATUTASO_H
#include "kerros.h"
#include "asunto.h"

class Katutaso
{
public:
    Katutaso();

    Asunto as1;
    Asunto as2;

    void maaritaAsunnot();
    double laskeKulutus(double);


private:

};

#endif // KATUTASO_H
