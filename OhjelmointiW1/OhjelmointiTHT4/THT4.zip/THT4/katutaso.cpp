#include "Katutaso.h"
#include <iostream>

Katutaso::Katutaso() {
    std::cout << "Katutaso luotu" << std::endl;
}

void Katutaso::maaritaAsunnot() {
    std::cout << "Maaritetaan 2kpl katutason asuntoja" << std::endl;
    as1.maarita(2, 100);
    as2.maarita(2, 100);
}

double Katutaso::laskeKulutus(double hinta) {
    double kulutus = as1.laskeKulutus(hinta) + as2.laskeKulutus(hinta);
   // std::cout << "Katutason kulutus, kun hinta = " << hinta << " on " << kulutus << std::endl;
    return kulutus;
}
