#include "Kerrostalo.h"
#include <iostream>

Kerrostalo::Kerrostalo() {
    std::cout << "Kerrostalo luotu" << std::endl;
}

double Kerrostalo::laskeKulutus(double hinta) {
    eka.maaritaAsunnot();
    toka.maaritaAsunnot();
    kolmas.maaritaAsunnot();

    double katutaso_kulutus = eka.laskeKulutus(hinta);
    double toka_kulutus = toka.laskeKulutus(hinta);
    double kolmas_kulutus = kolmas.laskeKulutus(hinta);

    double kerrostalo_kulutus = katutaso_kulutus + toka_kulutus + kolmas_kulutus;
    std::cout << "kerrostalon kulutus = "  << kerrostalo_kulutus << std::endl;
    return kerrostalo_kulutus;
}
